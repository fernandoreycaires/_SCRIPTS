#!/bin/bash

echo "Agora irá rolar uma atualização dos pacotes"

sudo apt update -y

echo "Agora uma atualização do sistema dos binarios"

sudo pkcon update -y

echo "Fim "

