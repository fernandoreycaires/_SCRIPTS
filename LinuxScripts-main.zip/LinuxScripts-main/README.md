# LinuxScripts

Scripts para estudo e automação de tarefas linux

Atribuir a permição nos arquivos antes de executa-los

chmod a+x nomedoarquivo
